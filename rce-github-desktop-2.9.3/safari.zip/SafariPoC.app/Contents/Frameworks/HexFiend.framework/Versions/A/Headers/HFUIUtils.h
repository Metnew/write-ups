#import <HexFiend/HFFrameworkPrefix.h>

NS_ASSUME_NONNULL_BEGIN

NSUInteger HFLineHeightForFont(HFFont *font);

NS_ASSUME_NONNULL_END
