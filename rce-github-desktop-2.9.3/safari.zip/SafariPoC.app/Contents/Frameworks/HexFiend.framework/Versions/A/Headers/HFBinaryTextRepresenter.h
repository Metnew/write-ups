//
//  HFBinaryTextRepresenter.h
//  HexFiend_2
//
//  Copyright 2020 ridiculous_fish. All rights reserved.
//

#import <HexFiend/HFTextRepresenter.h>

@interface HFBinaryTextRepresenter : HFTextRepresenter

@end
