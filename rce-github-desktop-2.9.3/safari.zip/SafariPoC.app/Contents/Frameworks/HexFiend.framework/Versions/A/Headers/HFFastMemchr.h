#include <stddef.h>

unsigned char *_Nullable HFFastMemchr(const unsigned char * _Nonnull s, unsigned char c, size_t n);
